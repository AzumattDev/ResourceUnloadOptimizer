| `Version` | `Update Notes`                                                                                             |
|-----------|------------------------------------------------------------------------------------------------------------|
| 1.0.2     | - Courtesy update, nothing changed internally. Just making the "Last Updated" date not seem like ages ago. |
| 1.0.1     | - README update.                                                                                           |
| 1.0.0     | - Initial Release                                                                                          |