| `Version` | `Update Notes`                                                                                                                                     |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.4     | - Version bump for Ashlands, make incompatible with servers, best used on clients.                                                                 |
| 1.0.3     | - Update the mod description. Update internal version as well because I have to since it won't match TS otherwise. Nothing about the code changed. |
| 1.0.2     | - Courtesy update, nothing changed internally. Just making the "Last Updated" date not seem like ages ago.                                         |
| 1.0.1     | - README update.                                                                                                                                   |
| 1.0.0     | - Initial Release                                                                                                                                  |